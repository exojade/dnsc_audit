<?php
    // configuration
    
    render("public/404_system/404form.php");
?>
